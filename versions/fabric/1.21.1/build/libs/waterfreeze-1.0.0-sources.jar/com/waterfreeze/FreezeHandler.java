package com.waterfreeze;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1690;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public class FreezeHandler {

    public static boolean shouldFreeze(class_1657 player) {
        boolean touchingWater = player.method_5799();
        WaterFreezeMod.LOGGER.info("shouldFreeze check for {}: touchingWater={}, inBoat={}, leatherArmor={}, worldIsServer={}",
            player.method_5477().getString(),
            touchingWater,
            isInBoat(player),
            hasLeatherArmor(player),
            player.method_37908() instanceof class_3218);

        if (!touchingWater) {
            return false;
        }

        if (isInBoat(player) || hasLeatherArmor(player)) {
            return false;
        }

        if (player.method_37908() instanceof class_3218 serverWorld) {
            class_2338 playerPos = player.method_24515();
            boolean snowing = isSnowingAt(serverWorld, playerPos);
            boolean iceNearby = hasIceNearby(serverWorld, playerPos);
            WaterFreezeMod.LOGGER.info("  pos={}, snowing={}, iceNearby={}, biome={}, raining={}",
                playerPos, snowing, iceNearby,
                serverWorld.method_23753(playerPos).comp_349().method_48162(playerPos),
                serverWorld.method_8419());
            return snowing || iceNearby;
        }

        return false;
    }

    private static boolean isSnowingAt(class_3218 world, class_2338 pos) {
        if (!world.method_8419()) {
            return false;
        }
        class_1959 biome = world.method_23753(pos).comp_349();
        return biome.method_48162(pos) == class_1959.class_1963.field_9383;
    }

    private static boolean hasIceNearby(class_3218 world, class_2338 pos) {
        for (class_2338 checkPos : class_2338.method_25996(pos, 1, 1, 1)) {
            if (world.method_8320(checkPos).method_27852(class_2246.field_10295)) {
                return true;
            }
        }
        for (class_2338 checkPos : class_2338.method_25996(pos, 3, 3, 3)) {
            if (world.method_8320(checkPos).method_27852(class_2246.field_10225)) {
                return true;
            }
        }
        for (class_2338 checkPos : class_2338.method_25996(pos, 5, 5, 5)) {
            if (world.method_8320(checkPos).method_27852(class_2246.field_10384)) {
                return true;
            }
        }
        return false;
    }

    private static boolean hasLeatherArmor(class_1657 player) {
        for (class_1799 stack : player.method_5661()) {
            if (stack.method_31574(class_1802.field_8267) ||
                stack.method_31574(class_1802.field_8577) ||
                stack.method_31574(class_1802.field_8570) ||
                stack.method_31574(class_1802.field_8370)) {
                return true;
            }
        }
        return false;
    }

    private static boolean isInBoat(class_1657 player) {
        class_1297 vehicle = player.method_5854();
        return vehicle instanceof class_1690;
    }
}
