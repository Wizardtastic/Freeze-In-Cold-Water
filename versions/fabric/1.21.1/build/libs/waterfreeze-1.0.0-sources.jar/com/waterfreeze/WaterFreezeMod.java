package com.waterfreeze;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_3222;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WaterFreezeMod implements ModInitializer {
    public static final String MOD_ID = "waterfreeze";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                tickPlayer(player);
            }
        });
        LOGGER.info("Water Freeze Mod initialized");
    }

    private static void tickPlayer(class_3222 player) {
        boolean shouldFreeze = FreezeHandler.shouldFreeze(player);

        if (shouldFreeze) {
            int threshold = player.method_32315();
            player.method_32317(threshold + 2);

            player.method_6092(new class_1293(
                class_1294.field_5909, 40, 0, false, false, true
            ));
        } else {
            if (player.method_32312() > 0) {
                player.method_32317(0);
            }
            player.method_6016(class_1294.field_5909);
        }
    }
}
